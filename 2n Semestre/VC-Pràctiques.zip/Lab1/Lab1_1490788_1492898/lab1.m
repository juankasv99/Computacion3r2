%% MEMBRES DEL GRUP
% Joel Moreno Barradas - 1490788
% Alex Blanes Diaz - 1492898



clearvars,
close all,
clc,


%% Problema 1 -----------------------------------
files = dir('./highway/input');
trainDataset = files(1053:1202); %de la 1051 a la 1200
testDataset = files(1203:1352); %de la 1201 a la 1350
%aux = rgb2gray(imread(strcat('./highway/input/',files(50).name)));
%imshow(aux);
%% Problema 2 -----------------------------------

mitjana = zeros(240,320,'double');
for i=1:150
    %img_aux = rgb2gray(imread(strcat('./highway/input/',trainDataset(i).name)));
    %imshow(img_aux);
    mitjana = mitjana + double(rgb2gray(imread(strcat('./highway/input/',trainDataset(i).name))));
end
mitjana = (mitjana ./ 150);
%figure(1)
%imshow(uint8(mitjana));

desvest = zeros(240,320,'double');
for i=1:150
    %img_aux = rgb2gray(imread(strcat('./highway/input/',trainDataset(i).name)));
    %imshow(img_aux);
    desvestAux = double(rgb2gray(imread(strcat('./highway/input/',trainDataset(i).name))))-double(mitjana);
    desvest = desvest + desvestAux.^2;
end
desvest = sqrt(desvest./150);
%figure(2)
%imshow(uint8(desvest));


%% Problema 3 -----------------------------------

% function [img_aux] = calculMitjana(img,thr,mitjana)
%     img_resta = abs(double(rgb2gray(imread(strcat('./highway/input/',img))))-double(mitjana));
%     img_aux = img_resta > thr;
% end



%% Problema 4 -----------------------------------

% function [img_aux] = calculElaborat(img,alfa,beta,mitjana,desvest)
%     img_resta = abs(double(rgb2gray(imread(strcat('./highway/input/',img))))-double(mitjana));
%     img_aux = img_resta > (alfa*desvest + beta);
% end



%% Problema 5 -----------------------------------
crearVideo('mitjana','',0.1,0.2,50, mitjana, desvest, testDataset);
evaluate(testDataset)
disp('--------------------------');
crearVideo('elaborat','',1,40,50, mitjana, desvest, testDataset);
evaluate(testDataset)
disp('--------------------------');

disp('FINAL DEL PROGRAMA');



function [] = crearVideo(mesura,opcio,alfa,beta,thr, mitjana, desvest, testDataset)
    image_folder = './video';
    if (mesura == "mitjana")
        disp('UTILITZANT MITJANA');
        video_name = 'videoMitjana.avi';
    else
        disp('UTILITZANT MESURA ELABORADA');
        video_name = 'videoElaborat.avi';
    end
    kernel = uint8(ones(5));
    
    if(exist(image_folder, 'dir') == 0) %si la carpeta no existe, la crea
        mkdir image_folder;
    end
    
    if (opcio == "erode")
        disp('Amb erode');
    else
        if (opcio == "dilate")
            disp('Amb dilate');
        else
            if (opcio == "open")
                disp('Amb open');
            end
        end
    end
    
    i = 0;
    for imatge=1:150
        if(mesura == "mitjana")
            frame_img = calculMitjana(testDataset(imatge).name, thr, mitjana);
        else
            frame_img = calculElaborat(testDataset(imatge).name, alfa, beta, mitjana, desvest);
        end
        frame_img = uint8(frame_img);
        
        if(opcio == "erode")
            frame_img = imerode(frame_img,kernel);
        else
            if(opcio == "dilate")
                frame_img = imdilate(frame_img,kernel);
            else
                if(opcio == "open")
                    frame_img = imopen(frame_img,kernel);
                else
                    if(opcio == "custom")
                        frame_img = imerode(frame_img,kernel);
                        frame_img = imdilate(frame_img,kernel);
                        frame_img = imdilate(frame_img,kernel);
                        frame_img = imdilate(frame_img,kernel);
                    end
                end
            end
        end
        imwrite(frame_img.*255,strcat(image_folder,'/',int2str(i),'.png'));
        i = i + 1;
    end
    
    %HACER EL VIDEO
    myVideo = VideoWriter(video_name, 'Uncompressed AVI');
    myVideo.FrameRate = 24;
    open(myVideo);
    for i = 0:149
        frame = strcat(image_folder, '/', int2str(i),'.png');
        writeVideo(myVideo, uint8(imread(frame)));
    end
    close(myVideo);
    
     
end


function [img_aux] = calculElaborat(img,alfa,beta,mitjana,desvest)
    img_resta = abs(double(rgb2gray(imread(strcat('./highway/input/',img))))-double(mitjana));
    img_aux = img_resta > (alfa.*desvest + beta);
end



function [img_aux] = calculMitjana(img,thr,mitjana)
    img_resta = abs(double(rgb2gray(imread(strcat('./highway/input/',img))))-double(mitjana));
    img_aux = img_resta > thr;
end

%% Problema 6 -----------------------------------

function [] = evaluate(testDataset)
    groundtruth = './highway/groundtruth';
    gtFiles = dir(groundtruth);
    gtDataset = gtFiles(1203:1352); %de la 1201 a la 1350
    video_folder = './video';
    accuracy = [];
    precision = [];
    recall = [];
    f1score = [];
    
    
    for i=1:150
        matrizGT = uint8(imread(strcat(groundtruth, '/',gtDataset(i).name)));
        matrizTEST = uint8(imread(strcat(video_folder, '/',int2str(i-1),'.png')));
        
        matAuxZERO = find(~matrizTEST);
        resZERO = matrizTEST(matAuxZERO) - matrizGT(matAuxZERO);
        matAuxUNO = find(matrizTEST);
        resUNO = matrizTEST(matAuxUNO) - matrizGT(matAuxUNO);
        
        sizeUNO = size(resUNO);
        sizeZERO = size(resZERO);
        TP = sizeUNO(1)*sizeUNO(2) - nnz(resUNO);
        TN = sizeZERO(1)*sizeUNO(2) - nnz(resZERO);
        FP = nnz(resUNO);
        FN = nnz(resZERO);
        accuracy = [accuracy, ((TP+TN)/(TP+TN+FP+FN))];
        precisionAux = TP/(TP+FP);
        precision = [precision, precisionAux];
        recallAux = TP/(TP+FN);
        recall = [recall, recallAux];
        f1score = [f1score, ((2*(recallAux*precisionAux))/(recallAux+precisionAux))];
    end
    
    disp(strcat('Accuracy: ',int2str(mean(accuracy)*100),'%'));
    disp(strcat('Precision: ',int2str(mean(precision)*100),'%'));
    disp(strcat('Recall: ',int2str(mean(recall)*100),'%'));
    disp(strcat('F1Score: ',int2str(mean(f1score)*100),'%'));
    
end
