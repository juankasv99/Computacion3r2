# -*- coding: utf-8 -*-
"""
Created on Tue Feb 25 14:44:16 2020

@author: joelm
"""

"""
MEMBRES DEL GRUP
Joel Moreno Barradas - 1490788
Alex Blanes Diaz - 1492898
"""

#------------------------------------------------------------------------------------------------------------------------

import time
import cv2 
import numpy as np
from matplotlib import pyplot as plt
import skimage
import os

#-------------PROBLEMA 1-------------------------------------------------------------------------------------------------
# Llistar imatges d'una carpeta.
files = os.listdir('./highway/input')
#print(files[1050]) #1051
trainDataset = files[1050:1200]
print('Imatges de train: ',len(trainDataset))
#print(files[1350]) #1350
testDataset = files[1201:1351]
print('Imatges de test: ',len(testDataset))
# Llegir una imatge en escala de gris.
#print(np.shape(skimage.io.imread((f'./highway/input/{files[1050]}'), as_grey=True)))
#-----------------------------------------------------------------------------------------------------------------------

#-------------PROBLEMA 2-------------------------------------------------------------------------------------------------
#Calcular la mitjana
mitjana = np.zeros_like(skimage.io.imread((f'./highway/input/{files[1050]}'), as_gray=True))

for img in trainDataset:
    mitjana += skimage.io.imread((f'./highway/input/{img}'), as_gray=True)
mitjana /= len(trainDataset)
#print(mitjana)
plt.title('Mitjana')
plt.imshow(mitjana, 'gray')
plt.show()

#Calcular la desviacio estandard
desvest = np.zeros_like(skimage.io.imread((f'./highway/input/{files[1050]}'), as_gray=True))
for img in trainDataset:
    desvest += abs(skimage.io.imread((f'./highway/input/{img}'), as_gray=True) - mitjana)**2
desvest = np.sqrt(desvest/len(trainDataset))
#print(desvest)
plt.title('Desviacio estandard')
plt.imshow(desvest, 'gray')
plt.show()
#-----------------------------------------------------------------------------------------------------------------------


#-------------PROBLEMA 3-------------------------------------------------------------------------------------------------
"""
threshold = 0.17

img_resta = abs(skimage.io.imread((f'./highway/input/{files[1300]}'), as_gray=True) - mitjana)
img_aux = img_resta[:,:] > threshold
plt.title('IMAGEN 1300')
plt.imshow(skimage.io.imread((f'./highway/input/{files[1300]}'), as_gray=True), 'gray')
plt.show()
plt.title('Prueba threshold')
plt.imshow(img_aux, 'gray')
plt.show()
"""
def calculMitjana(img, thr):
    img_resta = abs(skimage.io.imread((f'./highway/input/{img}'), as_gray=True) - mitjana)
    img_aux = img_resta[:,:] > thr
    return img_aux
#-----------------------------------------------------------------------------------------------------------------------



#-------------PROBLEMA 4-------------------------------------------------------------------------------------------------
"""
prueba_a = 0.1
prueba_b = 0.2
img_resta = abs(skimage.io.imread((f'./highway/input/{files[1300]}'), as_gray=True) - mitjana)
img_aux = img_resta[:,:] > (prueba_a*desvest + prueba_b)
plt.title('Prueba medida elaborada')
plt.imshow(img_aux, 'gray')
plt.show()
"""
def calculElaborat(img, alfa, beta):
    img_resta = abs(skimage.io.imread((f'./highway/input/{img}'), as_gray=True) - mitjana)
    img_aux = img_resta[:,:] > (alfa*desvest + beta)
    return img_aux
#-----------------------------------------------------------------------------------------------------------------------


#-------------PROBLEMA 5-------------------------------------------------------------------------------------------------
def crearVideo(mesura, opcio, alfa, beta, thr):
    image_folder = './video'
    if mesura == 'mitjana':
        print('UTILITZANT MITJANA')
        video_name = 'videoMitjana.avi'
    else:
        print('UTILITZANT MESURA ELABORADA')
        video_name = 'videoElaborat.avi'
    kernel = np.ones((5,5),np.uint8)
    
    #Creamos la carpeta si no existe
    try:
      os.stat(image_folder)
    except:
      os.mkdir(image_folder)
    
    if opcio == 'erode':
        print('Amb erode')
    elif opcio == 'dilate':
        print('Amb dilate')
    elif opcio == 'open':
        print('Amb open')
    
    
    i = 0
    for img in testDataset:
        if mesura == 'mitjana':
            frame_img = calculMitjana(img, thr)
        else:
            frame_img = calculElaborat(img, alfa, beta)
        frame_img = frame_img.astype(np.uint8)
        
        if opcio == 'erode':
            frame_img = cv2.erode(frame_img,kernel,iterations = 1) #Erode
        elif opcio == 'dilate':
            frame_img = cv2.dilate(frame_img,kernel,iterations = 1) #Dilate
        elif opcio == 'open':
            frame_img = cv2.morphologyEx(frame_img, cv2.MORPH_OPEN, kernel) #Open (erode + dilate)
        elif opcio == 'custom':
            frame_img = cv2.erode(frame_img,kernel,iterations = 1) #Erode
            frame_img = cv2.dilate(frame_img,kernel,iterations = 3) #Dilate
        
        cv2.imwrite((f'{image_folder}/{i}.png'),frame_img*255)
        i += 1
    
    images = [img for img in os.listdir(image_folder)]  
    sorted_images = sorted(images, key=lambda image:int(image.split(".")[0]))
    #print(sorted_images)
    frame = cv2.imread(os.path.join(image_folder, sorted_images[0]))
    height, width, layers = frame.shape
    
    fps = 24.0
    video = cv2.VideoWriter(video_name, cv2.VideoWriter_fourcc(*'DIVX'), fps, (width,height))
    cv2.VideoWriter()
    
    for image in sorted_images:
        video.write(cv2.imread(os.path.join(image_folder, image)))
    
    cv2.destroyAllWindows()
    video.release()
    

#-----------------------------------------------------------------------------------------------------------------------


#-------------PROBLEMA 6-------------------------------------------------------------------------------------------------
#Accuracy = (TP+TN)/(TP+TN+FP+FN)
def evaluate():
    groundtruth = os.listdir('./highway/groundtruth')
    gtDataset = groundtruth[1201:1351]
    
    accuracy = []
    precision = []
    recall = []
    f1score = []
    
    
    for i in range(len(gtDataset)):
        matrizGT = skimage.io.imread((f'./highway/groundtruth/{gtDataset[i]}'), as_gray=True)
        matrizTEST = skimage.io.imread((f'./video/{i}.png'), as_gray=True)        
        matrizTEST = matrizTEST.astype(np.uint8)

        matAuxZERO = np.where(matrizTEST == 0)
        resZERO = matrizTEST[matAuxZERO] - matrizGT[matAuxZERO]
        matAuxUNO = np.where(matrizTEST != 0)
        resUNO = matrizTEST[matAuxUNO] - matrizGT[matAuxUNO]
        
        TP = resUNO.size - np.count_nonzero(resUNO)
        TN = resZERO.size - np.count_nonzero(resZERO)
        FP = np.count_nonzero(resUNO)
        FN = np.count_nonzero(resZERO)
        
        accuracy.append((TP+TN)/(TP+TN+FP+FN))
        precisionAux = TP/(TP+FP)
        precision.append(precisionAux)
        recallAux = TP/(TP+FN)
        recall.append(recallAux)
        f1score.append((2*(recallAux*precisionAux))/(recallAux+precisionAux))
        
    print('Accuracy: ',np.median(accuracy)*100,'%')
    print('Precision: ',np.median(precision)*100,'%')
    print('Recall: ',np.median(recall)*100,'%')
    print('F1Score: ',np.median(f1score)*100,'%\n')

#-----------------------------------------------------------------------------------------------------------------------


for opt in ['mitjana','elaborat']:
    efectos = ['none', 'erode', 'dilate', 'open', 'custom']
    alfa = 0.1
    beta = 0.2
    threshold = 0.17
    crearVideo(opt, efectos[0], alfa, beta, threshold)
    evaluate()
