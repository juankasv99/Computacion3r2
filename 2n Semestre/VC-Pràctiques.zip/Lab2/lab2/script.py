import time
import cv2 as cv2
import numpy as np
import math as math
from matplotlib import pyplot as plt
from mpl_toolkits import mplot3d


imagenesAux = ['00187v','00331v','00467v','00480v','00491v']
for prueba in imagenesAux:
    print("Imagen: ", prueba)
    inputImg = prueba
    
    
    #Leemos la imagen (habra que pasar el nomber por parametro)
    img = cv2.imread(f'./inputs/{inputImg}.jpg', cv2.IMREAD_GRAYSCALE)
    
    #Mostramos la imagen
    #plt.imshow(img, 'gray')
    #plt.show()
    tiempo_inicial = time.time()
    #Calculamos el tamaño de la imagen original
    origImgShape = img.shape
    #print("shape: ", origImgShape)
    
    #Calculamos las divisiones para las tres imagenes r, g y b
    div = math.floor(origImgShape[0]/3)
    #print("div: ", div)
    
    #Generamos las 3 imagenes dividiendo la original
    rImg = img[0:div,:]
    gImg = img[div:2*div,:]
    bImg = img[2*div:3*div,:]
    finalImgShape = rImg.shape
    
    
    
    
    
    
    
    x = np.arange(0,30)
    #print("x: ", x)
    
    y = np.zeros(30)
    y[5:15] = 1
    #print("y: ", y)
    
    yd = np.zeros(30)
    yd[10:20] = 1
    #print("yd: ", yd)
    
    fy=np.fft.fft(y)
    #print("fy: ", fy)
    
    fyd=np.fft.fft(yd)
    #print("fyd: ", fyd)
    
    cfy = np.conjugate(fy)
    #print("cfy: ", cfy)
    
    correfft = cfy * fyd
    #print("correfft: ", correfft)
    
    correlacion = np.real(np.fft.ifft(correfft))
    #print("correlacion: ", correlacion)
    """
    plt.plot(x, correlacion)
    plt.show()
    """
    maximo = np.max(correlacion)
    #print("maximo: ", maximo)
    indice = np.where(correlacion==maximo)
    #print("indice: ", indice)
    
    
    
    
    
    
    
    
    
    
    #------------------FFT2--------------------
    x = np.arange(0,398)
    y = np.arange(0,341)
    x, y = np.meshgrid(x, y)
    
    fz = np.fft.fft2(rImg)
    
    
    
    fzd = np.fft.fft2(gImg)
    cfz = np.conjugate(fz)
    correfft = cfz * fzd
    correlacion = np.real(np.fft.ifft2(correfft))
    maximo = np.max(correlacion)
    #print("maximo: ", maximo)
    indice = np.where(correlacion==maximo)
    #print("indice: ", indice)
    gImg = np.roll(gImg, -indice[0], axis=0)
    gImg = np.roll(gImg, -indice[1], axis=1)
    
    fzd = np.fft.fft2(bImg)
    cfz = np.conjugate(fz)
    correfft = cfz * fzd
    correlacion = np.real(np.fft.ifft2(correfft))
    maximo = np.max(correlacion)
    #print("maximo: ", maximo)
    indice = np.where(correlacion==maximo)
    #print("indice: ", indice)
    bImg = np.roll(bImg, -indice[0], axis=0)
    bImg = np.roll(bImg, -indice[1], axis=1)
    
    
    #Mostramos la imagen resultante a color sin procesar
    imgResult = np.zeros((finalImgShape[0], finalImgShape[1],3)).astype(int)
    #Asignamos cada canal
    imgResult[:,:,0] = rImg
    imgResult[:,:,1] = gImg
    imgResult[:,:,2] = bImg
    
    #Guardamos la imagen resultante
    tiempo_final = time.time()
    cv2.imwrite(f'./outputs/{inputImg}_color.jpg', imgResult)
    print("Temps: ", tiempo_final-tiempo_inicial)
    
    
    
    #Borrar bordes
    imgShape = np.shape(imgResult)
    recorteAncho = int(imgShape[0]*5/100)
    recorteAlto = int(imgShape[1]*5/100)
    #print(imgShape, recorteAncho, recorteAlto)
    crop_img = imgResult[recorteAncho:imgShape[0]-recorteAncho, recorteAlto:imgShape[1]-recorteAlto,:]
    
    cv2.imwrite(f'./outputs/{inputImg}_crop.jpg', crop_img)
    
    
    
    #Gray world
    auxImg = crop_img
    gray_world_img = auxImg.transpose(2, 0, 1).astype(np.uint32)
    mu_g = np.average(gray_world_img[1])
    #print("Blanco: ", mu_g)
    gray_world_img[0] = np.minimum(gray_world_img[0]*(mu_g/np.average(gray_world_img[0])),255)
    gray_world_img[2] = np.minimum(gray_world_img[2]*(mu_g/np.average(gray_world_img[2])),255)
    gray_world_img = gray_world_img.transpose(1, 2, 0).astype(np.uint8)
    
    cv2.imwrite(f'./outputs/{inputImg}_GrayWorld.jpg', gray_world_img)
    
    
    
    #Estirar
    imgAux = gray_world_img
    stretch_img = imgAux.transpose(2, 0, 1)
    stretch_img[0] = np.maximum(stretch_img[0] - stretch_img[0].min(), 0)
    stretch_img[1] = np.maximum(stretch_img[1] - stretch_img[1].min(), 0)
    stretch_img[2] = np.maximum(stretch_img[2] - stretch_img[2].min(), 0)
    stretch_img = stretch_img.transpose(1, 2, 0)

    if stretch_img.dtype == np.uint8:
        brightest = float(2 ** 8)
    elif stretch_img.dtype == np.uint16:
        brightest = float(2 ** 16)
    elif stretch_img.dtype == np.uint32:
        brightest = float(2 ** 32)
    else:
        brightest = float(2 ** 8)
    stretch_img = stretch_img.transpose(2, 0, 1)
    stretch_img = stretch_img.astype(np.int32)
    stretch_img[0] = np.minimum(stretch_img[0] * (brightest / float(stretch_img[0].max())), 255)
    stretch_img[1] = np.minimum(stretch_img[1] * (brightest / float(stretch_img[1].max())), 255)
    stretch_img[2] = np.minimum(stretch_img[2] * (brightest / float(stretch_img[2].max())), 255)
    stretch_img = stretch_img.transpose(1, 2, 0).astype(np.uint8)
    
    cv2.imwrite(f'./outputs/{inputImg}_stretch.jpg', stretch_img)

    
    
    
    #Ecualizacion
    hist_img = stretch_img
    img_to_yuv = cv2.cvtColor(hist_img,cv2.COLOR_BGR2YUV)
    img_to_yuv[:,:,0] = cv2.equalizeHist(img_to_yuv[:,:,0])
    equalization_img = cv2.cvtColor(img_to_yuv, cv2.COLOR_YUV2BGR)
     
    cv2.imwrite(f'./outputs/{inputImg}_ecualization.jpg', equalization_img)
    
    """
    #Sharpening
    kernel_sharpening = np.array([[-1,-1,-1], [-1, 9,-1], [-1,-1,-1]])
    sharpened_img = cv2.filter2D(gray_world_img, -1, kernel_sharpening)
    cv2.imwrite(f'./outputs/{inputImg}_sharp.jpg', sharpened_img)
    """
    
    print("\n")
    #----------------------------------------------
    
    
    
    
    
    
    
    """
    x = np.arange(0,398)
    y = np.arange(0,341)
    
    x, y = np.meshgrid(x, y)
    
    z = rImg
    zd = np.roll(z, 10, axis=0)
    
    print("x: ", x.shape)
    print("y: ", y.shape)
    print("z: ", z.shape)
    print("zd: ", zd.shape)
    
    
    fz = np.fft.fft2(z)
    
    fzd = np.fft.fft2(zd)
    
    cfz = np.conjugate(fz)
    
    correfft = cfz * fzd
    
    correlacion = np.real(np.fft.ifft2(correfft))
    print("correlacion: ", correlacion.shape)
    
    fig = plt.figure()
    ax = plt.axes(projection='3d')
    ax.plot_surface(x, y, correlacion)
    plt.show()
    
    maximo = np.max(correlacion)
    print("maximo: ", maximo)
    
    indice = np.where(correlacion==maximo)
    print("indice: ", indice)
    """
    
    
    
    
    
    """
    x = np.arange(1,31)
    y = np.arange(1,31)
    
    z = np.zeros((30, 30))
    #print("z: ", z.shape)
    z[5:10,10:20] = 1
    
    zd = np.zeros((30, 30))
    zd[8:13,12:22] = 1
    
    fz = np.fft.fft2(z)
    
    fzd = np.fft.fft2(zd)
    
    cfz = np.conjugate(fz)
    
    correfft = cfz * fzd
    
    correlacion = np.real(np.fft.ifft2(correfft))
    #print("correlacion: ", correlacion)
    
    fig = plt.figure()
    ax = plt.axes(projection='3d')
    ax.plot_surface(x, y, correlacion, rstride=1, cstride=1,
            cmap='viridis', edgecolor='none')
    plt.show()
    
    maximo = np.max(correlacion)
    print("maximo: ", maximo)
    
    indice = np.where(correlacion==maximo)
    print("indice: ", indice)
    """
    
    
    
    
    
    
    """
    x = np.arange(1,129)
    print("x: ", x)
    
    y = np.zeros(128)
    y[50:80] = 1
    print("y: ", y)
    
    yd = np.zeros(128)
    yd[90:120] = 1
    print("yd: ", yd)
    
    fy=np.fft.fft(y)
    print("fy: ", fy)
    
    fyd=np.fft.fft(yd)
    print("fyd: ", fyd)
    
    cfy = np.conjugate(fy)
    print("cfy: ", cfy)
    
    correfft = cfy * fyd
    print("correfft: ", correfft)
    
    correlacion = np.real(np.fft.ifft(correfft))
    print("correlacion: ", correlacion)
    
    plt.plot(x, correlacion)
    plt.show()
    
    maximo = np.max(correlacion)
    print("maximo: ", maximo)
    indice = np.where(correlacion==maximo)
    print("indice: ", indice)
    """





