#include "Motxilla.h"



Motxilla::Motxilla()
{
}

Motxilla::Motxilla(vector<int> valors, vector<int> pesos, int capacitat_total, int n_elements)
{
	m_num_elements = n_elements;

	m_valors.resize(m_num_elements);
	m_pesos.resize(m_num_elements);

	for (int i = 0; i < m_num_elements; i++) {
		m_valors[i] = valors[i];
		m_pesos[i] = pesos[i];
	}
	m_capacitat_total = capacitat_total;

}

Motxilla::~Motxilla()
{
}

int Motxilla::knapSack_multiple(vector<vector<int>>& K)
{
// IMPLEMENTAR
}